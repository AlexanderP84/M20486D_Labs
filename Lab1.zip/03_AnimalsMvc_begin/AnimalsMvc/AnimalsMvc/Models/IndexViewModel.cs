﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AnimalsMvc.Models
{
    public class IndexViewModel
    {
        public List<Animal> Animals { get; set; }
    }
}
